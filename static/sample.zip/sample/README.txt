Phylodating sample data
https://bblab-hivresearchtools.ca/django/tools/phylodating/
Enter info.csv into "Info csv" and tree.nwk into "Unrooted tree" and press Submit to generate the phylodating....zip file (the exact name of the zip file will depend on the run id).