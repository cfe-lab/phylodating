Phylodating sample data

File contents:
info.csv - sample input file for Phylodating containing collection date and sequence type (calibration or query) of the sequences of the tree
tree.nwk - sample input file containing a newick tree
phylodating_5041336_2020-06-16-10 57 19.zip - output file from phylodating of the sample input. Contains four files (rooted_tree.nwk: an optimally rooted newick tree, stats.csv: a comma separated value file with model performance statistics, data.csv: a comma separated value file with the estimated dates, divergence_vs_time.png: a graphic relating the root-to-tip divergence versus collection dates of the sequences)
README.txt - this file

For more details visit https://bblab-hivresearchtools.ca/django/tools/phylodating/.

Instructions:
1. Unzip this archive.

2. Go to https://bblab-hivresearchtools.ca/django/tools/phylodating/

3. Enter the info.csv from this archive into "Info csv" and tree.nwk from this archive into "Unrooted tree"

4. Press "Submit" to start the run and you will be taken to a separate page

5. Refresh the page to check the status

6. When the "Download" button appears press it to download the results (the exact name of the output file phylodating...zip will depend on the application-generated run id and execution time, but the contents will be the same as the sample output file in this archive)